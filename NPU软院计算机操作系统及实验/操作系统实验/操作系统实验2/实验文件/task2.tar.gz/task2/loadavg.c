#include <linux/module.h>
#include <linux/kernel.h>
#include <linux/fs.h>
#include <linux/proc_fs.h>
#include <linux/uaccess.h>

#define PROC_NAME "loadavg"

static ssize_t loadavg_read(struct file *file, char __user *buffer, size_t count, loff_t *offset) {
char buf[128];
int len;

struct file *f = filp_open("/proc/loadavg", O_RDONLY, 0);
if (f == NULL) {
printk(KERN_ALERT "filp_open error\n");
return -EFAULT;
}

len = kernel_read(f, buf, sizeof(buf), &f->f_pos);
filp_close(f, NULL);

if (len < 0) {
return len;
}

if (copy_to_user(buffer, buf, len) != 0) {
return -EFAULT;
}

return len;
}

static const struct proc_ops proc_fops = {
.proc_read = loadavg_read,
};

static int __init loadavg_init(void) {
printk(KERN_INFO "Loading CPU Loadavg Module\n");
proc_create(PROC_NAME, 0, NULL, &proc_fops);
return 0;
}

static void __exit loadavg_exit(void) {
printk(KERN_INFO "Unloading CPU Loadavg Module\n");
remove_proc_entry(PROC_NAME, NULL);
}

module_init(loadavg_init);
module_exit(loadavg_exit);
MODULE_LICENSE("GPL");

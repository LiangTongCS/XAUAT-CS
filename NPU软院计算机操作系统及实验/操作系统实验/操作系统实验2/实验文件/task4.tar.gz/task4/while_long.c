#include <stdio.h>
#include <stdlib.h>

int main(int argc, char *argv[]) {
while (1) {
// Infinite loop to consume CPU time
}
printf("Over"); // This line will never be reached
exit(0);
}

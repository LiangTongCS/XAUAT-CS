#include <linux/module.h>
#include <linux/kernel.h>
#include <linux/sched/signal.h>

static int __init list_tasks_init(void) {
struct task_struct *task;
printk(KERN_INFO "Loading List Tasks Module\n");
for_each_process(task) {
if (task->state == TASK_RUNNING) {
printk(KERN_INFO "Process: %s [%d]\n", task->comm, task->pid);
}
}
return 0;
}

static void __exit list_tasks_exit(void) {
printk(KERN_INFO "Unloading List Tasks Module\n");
}

module_init(list_tasks_init);
module_exit(list_tasks_exit);
MODULE_LICENSE("GPL");
